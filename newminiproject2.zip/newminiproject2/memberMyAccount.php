<html>
<head>
	<title>My Account</title>
	<link rel="stylesheet" type="text/css" href="adminPage.css"/>
</head>

<style>
	table {
		font-family: arial, sans-serif;
		border-collapse: collapse;
		width: 100%;
		padding:10px;
	}

	td, th {
		border: 1px solid #dddddd;
		text-align: left;
		padding: 8px;
	}

	tr:nth-child(even) {
		background-color: #dddddd;
	}
</style>

<body>
	<a href="index.html" color="red">Logout</a>
	<div id="container">
		<div id="header">
		</div>
		<center><h1>Welcome to UMP-FSKKP Alumni Management System</h1></center>
		<div id="content">
		
			<div id="nav">
				<h2>Navigation</h2>
				
				<ul>
					<li><a href="memberMain.php">MAIN PAGE</li>
					<li><a href="memberA&E.php">ANNOUNCEMENT/EVENT</a></li>
					<li><a href="">MY ACCOUNT*</a></li>
					<li><a href="memberEforum.php">E-FORUM</a></li>
				
				</ul>
			</div>
			
			<div id="main">
			
				<h2>My Account</h2>
				
				<table>
					  <tr>
						<td>Name</td>
						<td></td>
					  </tr>
					  <tr>
						<td>Birthday</td>
						<td></td>
					  </tr>
					  <tr>
						<td>Job</td>
						<td></td>
					  </tr>
					  <tr>
						<td>Year Of Graduated</td>
						<td></td>
					  </tr>
					  <tr>
						<td>Batch</td>
						<td></td>
					  </tr>
					  <tr>
						<td>Program</td>
						<td></td>
					  </tr>
				</table>
				<br><br>
				
				<button type="submit" name="edit">Edit My Profile</button>
				<button type="submit" name="Update">Update My Profile</button>
				
				
			</div>
			
			
		
		</div>
		
		<div id="footer">
		
		<p> Copyright &copy; 2018 Chan Pui Fen & Kong Shin Yee</p>
		
		</div>
		
	</div>

</body>



</html>