<!DOCTYPE html>
<html>
<head>
	<title>Main Page</title>
	<link rel="stylesheet" type="text/css" href="main.css"/>
</head>

<body>
<a href="login.php" color="red">Member Login</a>
<a href="adminlogin.php" color="red">Admin Login</a>
<div class="header"></div>

<center><h1>Welcome to UMP-FSKKP Alumni Management System</h1></center>

<ul>
  <li><a href="index.html">Main</a></li>
  <li><a href="mainHistory.php">History</a></li>
  <li><a href="mainOChart.php">Organization Chart</a></li>
  <li><a href="mainContact.php">Contact</a></li>
  <li><a href="mainProcess.php">Process</a></li>
  <li><a href="">Address & Location</a></li>
</ul>


<center><h2>Where we are located</h2><center>
<strong><center><p class = "style1">
        Faculty Science Computer & Software Engineering<br>
        University Malaysia Pahang,<br>
        Gambang Campus,<br>
        Lebuhraya Tun Razak,<br> 
        Kampung Melayu Gambang,<br>
        26300 Gambang,<br>
        Pahang.
<br><br></center></strong>


</body>
</html>